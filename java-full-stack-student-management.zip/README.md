# Java Full Stack Student Management System

## Technologies
- Java 17
- Spring Boot
- Spring Web / REST API
- Spring Data JPA
- Hibernate
- MySQL
- HTML, CSS, JavaScript
- Maven

## Setup

1. Install JDK 17+, Maven, and MySQL.
2. Create the database:
   ```sql
   CREATE DATABASE studentdb;
   ```
3. Open `src/main/resources/application.properties`.
4. Replace `YOUR_MYSQL_PASSWORD` with your MySQL root password.
5. From the project folder run:
   ```bash
   mvn spring-boot:run
   ```
6. Open:
   `http://localhost:8080/`

## API endpoints
- GET `/api/students`
- GET `/api/students/{id}`
- GET `/api/students?search=monika`
- POST `/api/students`
- PUT `/api/students/{id}`
- DELETE `/api/students/{id}`

## Note about JDBC
The project uses MySQL Connector/J as the database driver. Spring Data JPA/Hibernate manages JDBC connections underneath the application, so you do not need to manually write `DriverManager` code for these CRUD operations. The earlier standalone JDBC concepts are still useful for understanding database connectivity.
