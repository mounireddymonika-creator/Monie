CREATE DATABASE IF NOT EXISTS studentdb;
USE studentdb;

-- Spring Boot/JPA creates the students table automatically.
-- Optional sample records:
INSERT INTO students (name, email, age, course)
VALUES
('Monika', 'monika@example.com', 21, 'B.Tech CSE'),
('Ravi', 'ravi@example.com', 22, 'B.Tech CSE');
