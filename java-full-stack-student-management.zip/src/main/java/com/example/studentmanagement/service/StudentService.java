package com.example.studentmanagement.service;

import com.example.studentmanagement.model.Student;
import com.example.studentmanagement.repository.StudentRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentService {
    private final StudentRepository repository;

    public StudentService(StudentRepository repository) {
        this.repository = repository;
    }

    public List<Student> getAll() {
        return repository.findAll();
    }

    public List<Student> search(String name) {
        if (name == null || name.isBlank()) return repository.findAll();
        return repository.findByNameContainingIgnoreCase(name);
    }

    public Student getById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Student not found"));
    }

    public Student save(Student student) {
        return repository.save(student);
    }

    public Student update(Long id, Student input) {
        Student student = getById(id);
        student.setName(input.getName());
        student.setEmail(input.getEmail());
        student.setAge(input.getAge());
        student.setCourse(input.getCourse());
        return repository.save(student);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }
}
